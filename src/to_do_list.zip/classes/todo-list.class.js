export class TodoList{

    constrctor (){

        this.todos = [];
    }
    nuevoTodo(todo){
        this.todos.push(todo);
    }
    eliminarTodo(id){
    
    }
    marcarCompletado(id){

    }
    eliminarCompletados(){

    }
}